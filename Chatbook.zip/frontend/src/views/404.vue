<script setup>
import Navbar from "../components/Navbar.vue";
</script>

<template>
    <Navbar></Navbar>
    <h1>404 - Sidan kunde inte hittas</h1>
</template>