export const formatNameForBackEnd = (name) => {
    return name.replace(/\s+/g, ".");
}
